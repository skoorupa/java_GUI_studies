package zad2;

import javax.swing.*;
import java.awt.*;

public class Staw extends JLabel {
    private static final int ROZMIAR = 80;
    public Staw() {
        this.setBackground(Color.CYAN);
        this.setSize(ROZMIAR, ROZMIAR);
        this.setOpaque(true);
    }
}
