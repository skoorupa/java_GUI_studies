package zad2;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.function.Consumer;

public class Zaba extends JPanel {
    private static final String[] IMAGES = {
            "frog1", "frog2"
    };
    private static final int ROZMIAR = 50;
    private static final int GRUBOSC_RAMKI = 2;

    private int numerGracza;
    private long kiedyNacisnietoMs = 0;

    private java.util.List<Consumer<MoveEvent>> moveListeners = new ArrayList<>();
    private java.util.List<Runnable> clickListeners = new ArrayList<>();

    public Zaba(int numerGracza) {
        this.numerGracza = numerGracza;
        setSize(ROZMIAR, ROZMIAR);
        setFocusable(true);

        this.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                setBorder(BorderFactory.createLineBorder(Color.BLACK, GRUBOSC_RAMKI));
            }

            @Override
            public void focusLost(FocusEvent e) {
                setBorder(BorderFactory.createEmptyBorder());
                // Poniższe nie działa zupełnie - ramka po prostu zostaje:
                //     Zaba.this.repaint();
                // Poniższe na ogół działa, z wyjątkiem końcowego momentu (ramka pozostaje poza stawem!):
                //     getParent().repaint(getX(), getY(), 1, 1);
                // Poniższe działa dobrze:
                getParent().repaint(
                        getX() - GRUBOSC_RAMKI,
                        getY() - GRUBOSC_RAMKI,
                        ROZMIAR + 2 * GRUBOSC_RAMKI,
                        ROZMIAR + 2 * GRUBOSC_RAMKI);
            }
        });

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                fireClickEvent();
            }
        });

        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP:
                    case KeyEvent.VK_DOWN:
                    case KeyEvent.VK_LEFT:
                    case KeyEvent.VK_RIGHT: break;
                    default: return;
                }
                if (kiedyNacisnietoMs > 0)
                    return;
                kiedyNacisnietoMs = System.currentTimeMillis();
                setBorder(BorderFactory.createLineBorder(Color.RED, GRUBOSC_RAMKI));
            }

            @Override
            public void keyReleased(KeyEvent e) {
                long ms = System.currentTimeMillis() - kiedyNacisnietoMs;
                int odleglosc = (int) (ms * ms * 1600 / 1000000);
                int x = Zaba.this.getX();
                int y = Zaba.this.getY();
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP:    y -= odleglosc; break;
                    case KeyEvent.VK_DOWN:  y += odleglosc; break;
                    case KeyEvent.VK_LEFT:  x -= odleglosc; break;
                    case KeyEvent.VK_RIGHT: x += odleglosc; break;
                    default: return;
                }
                kiedyNacisnietoMs = 0;
                setBorder(BorderFactory.createLineBorder(Color.BLACK, GRUBOSC_RAMKI));
                fireMoveEvent(new MoveEvent(x, y));
            }
        });
    }

    public int getNumerGracza() {
        return numerGracza;
    }

    public void addMoveListener(Consumer<MoveEvent> l) {
        this.moveListeners.add(l);
    }
    public void addClickListener(Runnable r) { this.clickListeners.add(r); }

    public void fireMoveEvent(MoveEvent e) {
        for (Consumer<MoveEvent> l: moveListeners) {
            l.accept(e);
        }
    }

    public void fireClickEvent() {
        for (Runnable r: clickListeners) {
            r.run();
        }
    }

    public Point getCenter() {
        return new Point(getX() + getWidth() / 2, getY() + getHeight() / 2);
    }

    @Override
    public void paintComponent(Graphics g) {
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new File("assets/" + IMAGES[numerGracza] + ".png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        g.drawImage(bi, 0, 0, getWidth(), getHeight(), null);
    }
}
    