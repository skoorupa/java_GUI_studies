package zad2;

import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {
    private static final int BOK_PLANSZY = 800;

    public Main() {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        JLabel wynik = new JLabel();
        wynik.setPreferredSize(new Dimension(BOK_PLANSZY, 50));
        wynik.setFont(wynik.getFont().deriveFont(40f));
        wynik.setHorizontalAlignment(SwingConstants.CENTER);
        this.add(wynik, BorderLayout.PAGE_START);
        Plansza p = new Plansza(BOK_PLANSZY);
        p.addGameEndListener((i) -> wynik.setText("Gracz " + i + " wygrał!"));
        this.add(p);
        this.pack();
        this.setVisible(true);
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> new Main());
    }
}
