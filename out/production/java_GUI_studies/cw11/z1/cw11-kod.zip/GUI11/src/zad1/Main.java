package zad1;

import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {
    private static final int ROZMIAR = 800;

    public Main() {
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel jp = new JPanel();
        jp.setPreferredSize(new Dimension(ROZMIAR, ROZMIAR));
        this.add(jp);
        this.pack();

        Zaba z = new Zaba();
        jp.add(z);
        this.setVisible(true);

        z.addMoveListener((MoveEvent e) -> {
            int oldX = z.getX();
            int oldY = z.getY();
            int newX = Math.max(0, Math.min(e.getNewX(), ROZMIAR - z.getWidth()));
            int newY = Math.max(0, Math.min(e.getNewY(), ROZMIAR - z.getHeight()));
            z.setLocation(newX, newY);
            repaint(oldX, oldY, 1, 1);
            repaint(newX, newY, 1, 1);
        });
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> new Main());
    }
}
