package zad2;

public class MoveEvent {
    private int newX;
    private int newY;

    public MoveEvent(int newX, int newY) {
        this.newX = newX;
        this.newY = newY;
    }

    public int getNewX() {
        return newX;
    }

    public int getNewY() {
        return newY;
    }
}
