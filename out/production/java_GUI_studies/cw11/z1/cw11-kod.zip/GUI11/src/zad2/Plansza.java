package zad2;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.function.Consumer;

public class Plansza extends JPanel {
    private int size;

    private Zaba[] zaby;
    private Staw staw;
    private int numerGracza = 0;


    private java.util.List<Consumer<Integer>> gameEndListeners = new ArrayList<>();

    public Plansza(int size) {
        this.size = size;
        this.setLayout(null);
        this.setPreferredSize(new Dimension(size, size));

        zaby = new Zaba[] {
                centrujW(new Zaba(0), size / 10, size / 10),
                centrujW(new Zaba(1), size / 10, size * 9 / 10),
                centrujW(new Zaba(0), size * 9 / 10, size * 9 / 10),
                centrujW(new Zaba(1), size * 9 / 10, size / 10),
        };
        staw = centrujW(new Staw(), size / 2, size / 2);

        for (Zaba z: zaby) {
            this.add(z);
            z.addClickListener(() -> {
                if (z.getNumerGracza() == numerGracza) {
                    z.grabFocus();
                }
            });
            z.addMoveListener((e) -> zabaMoved(z, e));
        }

        this.add(staw);
    }

    public void zabaMoved(Zaba z, MoveEvent e) {
        int oldX = z.getX();
        int oldY = z.getY();
        int newX = Math.max(0, Math.min(e.getNewX(), size - z.getWidth()));
        int newY = Math.max(0, Math.min(e.getNewY(), size - z.getHeight()));
        z.setLocation(newX, newY);
        repaint(oldX, oldY, z.getWidth(), z.getHeight());
        repaint(newX, newY, z.getWidth(), z.getHeight());
        if (staw.getBounds().contains(z.getCenter())) {
            for (Zaba z2: zaby) {
                z2.setFocusable(false);
            }
            fireGameEndEvent();
        } else {
            numerGracza = 1 - numerGracza;
            for (Zaba z2: zaby) {
                z2.setFocusable(z2.getNumerGracza() == numerGracza);
            }
        }
    }

    public <T extends Component> T centrujW(T comp, int x, int y) {
        comp.setLocation(x - comp.getWidth() / 2, y - comp.getHeight() / 2);
        return comp;
    }

    public void addGameEndListener(Consumer<Integer> l) {
        this.gameEndListeners.add(l);
    }

    public void fireGameEndEvent() {
        for (Consumer<Integer> l : gameEndListeners) {
            l.accept(numerGracza);
        }
    }
}
