package zad1;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.function.Consumer;

public class Zaba extends JLabel {
    private static final int ROZMIAR = 50;
    private static final int GRUBOSC_RAMKI = 2;

    private long kiedyNacisnietoMs = 0;

    private java.util.List<Consumer<MoveEvent>> moveListeners = new ArrayList<>();

    public Zaba() {
        setFocusable(true);
        setPreferredSize(new Dimension(ROZMIAR, ROZMIAR));
        setBorder(BorderFactory.createLineBorder(Color.BLACK, GRUBOSC_RAMKI));

        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP:
                    case KeyEvent.VK_DOWN:
                    case KeyEvent.VK_LEFT:
                    case KeyEvent.VK_RIGHT: break;
                    default: return;
                }
                if (kiedyNacisnietoMs > 0)
                    return;
                kiedyNacisnietoMs = System.currentTimeMillis();
                setBorder(BorderFactory.createLineBorder(Color.RED, GRUBOSC_RAMKI));
            }

            @Override
            public void keyReleased(KeyEvent e) {
                long ms = System.currentTimeMillis() - kiedyNacisnietoMs;
                int odleglosc = (int) (ms * ms * 1600 / 1000000);
                int x = Zaba.this.getX();
                int y = Zaba.this.getY();
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP:    y -= odleglosc; break;
                    case KeyEvent.VK_DOWN:  y += odleglosc; break;
                    case KeyEvent.VK_LEFT:  x -= odleglosc; break;
                    case KeyEvent.VK_RIGHT: x += odleglosc; break;
                    default: return;
                }
                setBorder(BorderFactory.createLineBorder(Color.BLACK, GRUBOSC_RAMKI));
                kiedyNacisnietoMs = 0;
                fireMoveEvent(new MoveEvent(x, y));
            }
        });
    }

    public void addMoveListener(Consumer<MoveEvent> l) {
        this.moveListeners.add(l);
    }

    public void fireMoveEvent(MoveEvent e) {
        for (Consumer<MoveEvent> l : moveListeners) {
            l.accept(e);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(new File("assets/frog1.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        g.drawImage(bi, 0, 0, ROZMIAR, ROZMIAR, null);
    }
}
